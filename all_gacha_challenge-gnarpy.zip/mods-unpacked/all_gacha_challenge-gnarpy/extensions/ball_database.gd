extends "res://singletons/ball_database.gd"

func get_different_balls_with_rarity_prefer_first_set(amount = 2, exclude_ids = [], exclude_tags = [], required_tags = [], from_sets = []):
    if from_sets.size() == 7:
        var chosen_balls = []
        var gacha_ball
        for ball in balls:
            if ball.id == "GACHA":
                gacha_ball = ball
        for i in range(amount):
            chosen_balls.append(gacha_ball)
        return chosen_balls
    else:
        return super(amount, exclude_ids, exclude_tags, required_tags, from_sets)
